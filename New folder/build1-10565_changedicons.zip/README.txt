This archive was downloaded from The Windows 10 Icons database at icons.bav0.com.
The contents of this archive are intended for personal use only. You may not use or redistribute its contents.
All icons included in this archive were originally distributed as part of Microsoft Windows, all rights belong to the original author.

The Windows 10 Icons Database is not afilliated with, maintained, sponsored or endorsed by Microsoft. 
"Microsoft" and "Windows" are trademarks of Microsoft.